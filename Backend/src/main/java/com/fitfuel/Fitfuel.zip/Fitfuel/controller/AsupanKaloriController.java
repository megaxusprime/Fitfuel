package com.fitfuel.Fitfuel.controller;

import com.fitfuel.Fitfuel.model.AsupanKalori;
import com.fitfuel.Fitfuel.repository.AsupanKaloriRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/asupan")
public class AsupanKaloriController {

    @Autowired
    private AsupanKaloriRepository asupanKaloriRepository;

    // Input Asupan Kalori
    @PostMapping
    public ResponseEntity<AsupanKalori> inputAsupan(@RequestBody AsupanKalori asupanKalori) {
        AsupanKalori savedAsupan = asupanKaloriRepository.save(asupanKalori);
        return ResponseEntity.ok(savedAsupan);
    }

    // Lihat Riwayat Asupan Kalori
    @GetMapping
    public ResponseEntity<List<AsupanKalori>> getRiwayatAsupan() {
        List<AsupanKalori> riwayat = asupanKaloriRepository.findAll();
        return ResponseEntity.ok(riwayat);
    }
}
